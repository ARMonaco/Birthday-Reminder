export class Order {
   constructor(
      public name: string,
      public email: string,
      public option: string[],
      public comment: string
   ){}
}
