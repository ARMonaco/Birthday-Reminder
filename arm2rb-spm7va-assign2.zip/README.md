# Birthday-Reminder
CS4640 Project

Alexander Monaco & Shreyas Mehta

NOTE TO SHREYAS (since I don't think I'll be awake when you wake up):
Because of how the navbar is included, this only works on XAMPP. I found it easiest to just copy the files from my git directory into the xampp folder and then put the modified versions back to push to the repo. To get the navbar working, look at the top sections of profile or logout.html. (logout.html is less cluttered, so it's probably easier.) 

If you are working on the login page first, we might have to make a modified version of the navbar that doesn't have the links to the home/profile/logout pages but we can discuss that as it arises.
